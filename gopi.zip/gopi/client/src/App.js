import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [quote, setQuote] = useState('');
  const [author, setAuthor] = useState('');
  const [authorQuotes, setAuthorQuotes] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3030/quote')
      .then((response) => response.json())
      .then((data) => {
        setQuote(data.quote);
      })
      .catch((error) => {
        console.error('Error fetching quote:', error);
        setQuote('Failed to fetch the quote. Please try again later.');
      });
  }, []);

  const handleAuthorSearch = () => {
    fetch(`http://localhost:3030/quote/author/${author}`)
      .then((response) => response.json())
      .then((data) => {
        setAuthorQuotes(data.quotes);
      })
      .catch((error) => {
        console.error('Error fetching author quotes:', error);
        setAuthorQuotes(['Failed to fetch author quotes. Please try again later.']);
      });
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Quote of the Day</h1>
        <p>{quote ? `"${quote}"` : 'Loading...'}</p>
      </header>
      <div className="Author-search">
        <input
          type="text"
          placeholder="Author's Name"
          value={author}
          onChange={(e) => setAuthor(e.target.value)}
        />
        <button onClick={handleAuthorSearch}>Search by Author</button>
      </div>
      <div className="Author-quotes">
        <h2>Quotes by Author</h2>
        <ul>
          {authorQuotes.map((quote, index) => (
            <li key={index}>{`"${quote}"`}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
