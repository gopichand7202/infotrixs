const express = require('express');
const axios = require('axios');
const app = express();
const port = 3030;

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*'); // Allow cross-origin requests (be cautious in production)
  next();
});

app.get('/quote', async (req, res) => {
  try {
    const apiUrl = 'https://zenquotes.io/api/today';
    const response = await axios.get(apiUrl);
    const quote = response.data[0].q;
    res.json({ quote });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch the quote' });
  }
});

app.get('/quote/author/:authorName', async (req, res) => {
  try {
    const authorName = req.params.authorName;
    const apiUrl = `https://zenquotes.io/api/quotes/author/${authorName}`;
    const response = await axios.get(apiUrl);
    const quotes = response.data.map((quote) => quote.q);
    res.json({ quotes });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch quotes by author' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
